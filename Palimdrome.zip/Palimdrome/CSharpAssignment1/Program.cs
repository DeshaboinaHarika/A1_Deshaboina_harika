﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Word
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the String");
            //read the input word from user
            String word = Console.ReadLine();
            //declaring rev_word to store the reverse of given word
            String rev_word = "";
            for(int i=word.Length-1;i>=0; i--)
            {
                //reversing of given word
                rev_word +=word[i].ToString();
            }
            //comparing the reverse of word and given word
            if(rev_word==word)
            {
                Console.WriteLine("Given word is Palindrome");
            }
            else
            {
                Console.WriteLine("Given word is not Palindrome");
            }
            Console.ReadLine();
        }
    }
}
