﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiplication
{
    class Table
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            //taking the datatype aas short because only few number tables are required
            //converting the read input to int as ReadLine accepts only String values as input
            short num = Convert.ToInt16(Console.ReadLine());
           
            for(int i=1;i<=10;i++)
            {
                Console.WriteLine(num + "*" + i + "=" + num * i);
                
            }
            Console.ReadLine();
        }
    }
}
