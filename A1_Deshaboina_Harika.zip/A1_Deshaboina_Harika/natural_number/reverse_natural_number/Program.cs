﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reverse_natural_number
{
    class Program
    {
        static void Main(string[] args)
        {
            byte number = 10;
            Console.WriteLine("Reverse of Natural numbers are ");
            for(number=10;number!=0;number--)
            {
                Console.WriteLine("" + number);
            }
            Console.ReadLine();
        }
    }
}
