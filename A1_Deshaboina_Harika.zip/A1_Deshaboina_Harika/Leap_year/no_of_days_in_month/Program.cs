﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace no_of_days_in_month
{
    class input
    {
        static void Main(string[] args)
        {
            St
        }
    }
}
