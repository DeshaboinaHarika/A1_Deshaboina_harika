﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sum_of_integer
{
    class Sum
    {
        static void Main(string[] args)
        {
            int sum = 0, number = 0, x = 0;
            Console.WriteLine("Enter the number");
            number = Convert.ToInt16(Console.ReadLine());
            x = number;
            while(number!=0)
            {
                x= number % 10;
                sum += x;
                number = number / 10;
            }
            Console.WriteLine("Sum of Entered digits is" + sum);
            Console.ReadLine();

        }
    }
}
