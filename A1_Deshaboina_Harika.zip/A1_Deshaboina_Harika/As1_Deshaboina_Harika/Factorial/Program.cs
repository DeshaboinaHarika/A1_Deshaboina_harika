﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorial
{
    class Prime
    {
        static void Main(string[] args)
        {
            int factorial = 1, number = 0, a = 0,x=0;
            byte flag = 0;
            Console.WriteLine("Enter the number");
            number = Convert.ToInt16(Console.ReadLine());
            for(a=1;a<=number;a++)
            {
                factorial = factorial * a;
            }
            x = factorial/2;
            for (a = 2; a <= x; a++)
            {
                if (factorial % a == 0)
                {
                    Console.WriteLine("Number is not Prime.");
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
                Console.WriteLine("Number is Prime.");
            Console.ReadLine();

        }
    }
}
