﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Natural_number
{
    class Program
    {
        static void Main(string[] args)
        {
            byte a = 1;
            Console.WriteLine("First 10 natural numbers are");
            for(a=1;a<=10;a++)
            {
                Console.WriteLine(" " + a);
            }
            Console.ReadLine();
        }
    }
}
