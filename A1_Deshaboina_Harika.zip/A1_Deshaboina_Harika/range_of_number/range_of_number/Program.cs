﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace range_of_number
{
    class Program
    {
        static void Main(string[] args)
        {
            short first_number = 0, last_number = 0;
            Console.WriteLine("Enter the first number");
            first_number = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter the last number");
            last_number = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("the numbers between the given range of numbers are");
            for(int i=first_number;i<=last_number;i++)
            {
                Console.WriteLine("" + i);
            }
            Console.ReadLine();
        }
    }
}
