﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prime_number
{
    class Program
    {
        static void Main(string[] args)
        {
           int number = 0, i = 0;
           byte flag=0;
            Console.WriteLine("Enter the number");
            number = Convert.ToInt16(Console.ReadLine());
            for(i=1; i<=number/2;i++)
            {
                if(number%i==0)
                {
                    flag++;
                }
            }
            if(flag==2)
            {
                Console.WriteLine("the give number is not prime");
            }
            else
            {
                Console.WriteLine("the given number is  prime");
            }
            Console.ReadLine();
        }
    }
}
