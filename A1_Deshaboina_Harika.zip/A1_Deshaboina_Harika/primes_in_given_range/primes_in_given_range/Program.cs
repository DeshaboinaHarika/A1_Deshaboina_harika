﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace primes_in_given_range
{
    class Program
    {
        static void Main(string[] args)
        {
            byte flag = 0;
            Console.WriteLine("The primes between 2 and 100 are");
            for(int i=2;i<=100;i++)
            {
                flag = 0;
                for (int j = 1; j <= i / 2; j++)
                {
                    if (i % j == 0)
                    {
                        flag++;
                        break;
                    }
                }  
                    if (flag == 1&&i!=0)
                    {
                    Console.WriteLine(""+i);
                    //break;
                    }
                   // else
                  //  {
                    //    Console.WriteLine("" + i);
                    //}
                
            }
            Console.ReadLine();
        }
    }
}
