﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace No_of_days_in_month
{
    class Program
    {
        static void Main(string[] args)
        {
            String month;
            int year,leapyear=0;
            Console.WriteLine("Enter the month");
            month = Console.ReadLine();
            Console.WriteLine("Enter year");
            year = Convert.ToInt16(Console.ReadLine());
            if (year % 4 == 0 | year % 400==0)
                leapyear = 1;
            if (month == "february" & leapyear == 1)
                Console.WriteLine("No.of days in {0} is 29", month);
            else if(month=="february")
                Console.WriteLine("No.of days in {0} is 28", month);
            if (month == "january" | month == "march" | month == "may" | month == "july" | month == "august" | month == "october" | month == "december")
                Console.WriteLine("No.of days in {0} month is 31", month);
            else if (month == "april" | month == "june" | month == "september" | month == "november")
                Console.WriteLine("No.of days in {0} month is 30", month);
            Console.ReadLine();
        }
       
    }
}
