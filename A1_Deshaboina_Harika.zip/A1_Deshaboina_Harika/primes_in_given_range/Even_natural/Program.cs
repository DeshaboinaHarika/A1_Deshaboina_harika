﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Even_natural
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("The first ten even natural numbers are");
            for(int i=1;i<=20;i++)
            {
                if(i%2==0)
                {
                    Console.WriteLine("" + i);
                }
            }
            Console.ReadLine();
        }
    }
}
