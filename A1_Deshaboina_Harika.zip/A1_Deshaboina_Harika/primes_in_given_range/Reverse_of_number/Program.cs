﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reverse_of_number
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            int number = 0, reverse = 0, a = 0;
            number = Convert.ToInt16(Console.ReadLine());
            while(number!=0)
            {
                a = number % 10;
                reverse = reverse * 10 + a;
                number = number / 10;
            }
            Console.WriteLine("Reverse of the given number is" + reverse);
            Console.ReadLine();
        }
    }
}
