﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ncr
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, c, r, difference,n_fact,r_fact;
            Console.WriteLine("Enter the value of n");
            n = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter the value of r");
            r = Convert.ToInt16(Console.ReadLine());
            n_fact = fact(n);
            r_fact = fact(r);
            difference = fact(n - r);
            c = n_fact / (difference * r_fact);
            Console.WriteLine("ncr value is" + c);
            int fact(int num)
            {
                int sample=1;
                if (num == 0)
                    return 1;
                else
                {
                    for(int i=1;i<=num;i++)
                    {
                        sample *= i;
                    }
                }
                return sample;
            }
            Console.ReadLine();
        }
    }
}
